import logo from './logo.svg';
import './App.css';
import Weather from './Weather';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
        <h1>WEATHER</h1>
        <Weather/>
    </div>
  );
}

export default App;
